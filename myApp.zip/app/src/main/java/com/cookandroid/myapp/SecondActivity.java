package com.cookandroid.myapp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.EmbossMaskFilter;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {
    Button ibzoomin, ibzoomout, ibrotate, ibbright, ibdark, ibgray, ibblur, ibemboss;

    MyGraphicView graphicView;

    static float scaleX=1, scaleY=1;

    static float angle = 0;

    static float color = 1;

    static  float satur = 1;

    static  float blur = 1;

    static float emboss = 0;

    static float em1=0, em2=0, em3=0, em4=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second);
        setTitle("미니 포토샵");

        LinearLayout pictureLayout = (LinearLayout) findViewById(R.id.pictureLayout);
        graphicView = (MyGraphicView) new MyGraphicView(this);
        pictureLayout.addView(graphicView);

        clickIcons();
    }

    private static  class MyGraphicView extends View {
        public  MyGraphicView(Context context) {
            super(context);
        }

        BlurMaskFilter bmask;

        EmbossMaskFilter emask;

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            int cenX = this.getWidth() / 2;
            int cenY = this.getHeight() / 2;

            canvas.scale(scaleX, scaleY, cenX, cenY);
            canvas.rotate(angle, cenX, cenY);

            Bitmap picture = BitmapFactory.decodeResource(getResources(), R.drawable.as2);

            int picX = (this.getWidth() - picture.getWidth()) / 2;
            int picY = (this.getHeight() - picture.getHeight()) / 2;

            Paint paint = new Paint();

            bmask = new BlurMaskFilter(blur, BlurMaskFilter.Blur.NORMAL);

            emask = new EmbossMaskFilter(new float[] {emboss, em1, em2}, 0.5f, em3, em4);

            float[] array = {
                    color, 0, 0, 0, 0,
                    0, color, 0, 0, 0,
                    0, 0, color, 0, 0,
                    0, 0, 0, 1, 0, 0
            };
            ColorMatrix cm = new ColorMatrix(array);

            if (satur == 0) {
                cm.setSaturation(satur);
            }

            paint.setColorFilter(new ColorMatrixColorFilter(cm));

            if (blur == 30) {
                paint.setMaskFilter(bmask);
            } else if (emboss == 3) {
                paint.setMaskFilter(emask);
            }

            canvas.drawBitmap(picture, picX, picY, paint);
            picture.recycle();
        }
    }

    private  void clickIcons() {
        ibzoomin = (Button) findViewById(R.id.ibzoomin);
        ibzoomin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                scaleX = scaleX + 0.2f;
                scaleY = scaleY + 0.2f;
                graphicView.invalidate();
            }
        });

        ibzoomout = (Button) findViewById(R.id.ibzoomout);
        ibzoomout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                scaleX = scaleX - 0.2f;
                scaleY = scaleY - 0.2f;
                graphicView.invalidate();
            }
        });

        ibrotate = (Button) findViewById(R.id.ibrotate);
        ibrotate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                angle = angle + 20;
                graphicView.invalidate();
            }
        });

        ibbright = (Button) findViewById(R.id.ibbright);
        ibbright.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                color = color + 0.2f;
                graphicView.invalidate();
            }
        });

        ibdark = (Button) findViewById(R.id.ibdark);
        ibdark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                color = color - 0.2f;
                graphicView.invalidate();
            }
        });

        ibgray = (Button) findViewById(R.id.ibgray);
        ibgray.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (satur == 0) {
                    satur = 1;
                } else {
                    satur = 0;
                }
                graphicView.invalidate();
            }
        });

        ibblur = (Button) findViewById(R.id.ibblur);
        ibblur.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (blur == 1) {
                    blur = 30;
                } else {
                    blur = 1;
                }
                graphicView.invalidate();
            }
        });

        ibemboss = (Button) findViewById(R.id.ibemboss);
        ibemboss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (emboss == 0) {
                    emboss = 3;
                    em1 = 3;
                    em2 = 3;
                    em3 = 5;
                    em4 = 10;
                } else {
                    emboss = 0;
                    em1 = 0;
                    em2 = 0;
                    em3 = 0;
                    em4 = 0;
                }
                graphicView.invalidate();
            }
        });

    }
}
